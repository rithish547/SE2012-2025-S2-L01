import java.util.Scanner;

public class Marks {
    public static void main(String[] args){
        System.out.println("Welcome to Marks adding and viewing system.");
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter # of students in the class: ");
        int n = scan.nextInt();
        int[][] Students = new int[n + 1][3];
        int choice;

        boolean running = true;
        while (running){
            System.out.println("Enter a Choice from 1-6.");
            System.out.println("1. Add Student Marks.");
            System.out.println("2. Update Mark.");
            System.out.println("3. Get Average for a subject.");
            System.out.println("4. Get Total mark of a Student.");
            System.out.println("5. Get Average for a Student.");
            System.out.println("6. To Exit the program.");
            System.out.println("7. Grading");
            System.out.print("Enter choice: ");
            choice = scan.nextInt();

            switch (choice){
                case 1:
                    System.out.print("Please enter student id (in range 1 to " + n +"): ");
                    int stdId = scan.nextInt();

                    if (stdId >= 1 && stdId <= n){
                        System.out.print("Enter the marks for Mathematics: ");
                        Students[stdId][0] = scan.nextInt();
                        System.out.print("Enter the marks for Chemistry: ");
                        Students[stdId][1] = scan.nextInt();
                        System.out.print("Enter the marks for Physics: ");
                        Students[stdId][2] = scan.nextInt();

                        System.out.println("Marks added");
                    }else{
                        System.out.println("Invalid students ID.");
                    }
                    break;

                case 2:
                    System.out.print("Please enter student ID (in range 1 to " + n+ "): ");
                    int stdNo = scan.nextInt();

                    System.out.print("Enter subj id (1: Math, 2: Chem, 3:Physics): ");
                    int subjId = scan.nextInt();

                    if (stdNo >= 1 && stdNo <= n && subjId >= 1 && subjId <= 3){
                        System.out.println("Update the mark. Enter: ");
                        Students[stdNo][subjId - 1] = scan.nextInt();
                        System.out.println("Marks updated");

                    }
                    else{
                        System.out.println("Invalid students ID or Subject ID.");
                    }
                    break;

                case 3:
                    System.out.print("Enter subj id (1: Math, 2: Chem, 3:Physics): ");
                    int subjNo = scan.nextInt();
                    if (subjNo >= 1 && subjNo <= 3){
                        int totalMarks = 0;
                        for (int i = 1; i <= n; i++){
                            totalMarks += Students[i][subjNo - 1];
                        }
                        System.out.println("Average marks for subject: " + (totalMarks/n));
                    }
                    else{
                        System.out.println("Invalid Subject ID.");
                    }
                    break;
                case 4:
                    System.out.print("Enter student ID: ");
                    int std_id = scan.nextInt();
                    if (std_id >= 1 && std_id <= n){
                        int tot = Students[std_id][0] + Students[std_id][1] +  Students[std_id][2];
                        System.out.println("Average marks for student: " + (tot/n));
                    }
                    else{
                        System.out.println("Invalid Student ID.");
                    }
                    break;
                case 5:
                    System.out.print("Enter student Id: ");
                    int std_Id = scan.nextInt();
                    if (std_Id >= 1 && std_Id <= n){
                        int tot = Students[std_Id][0] + Students[std_Id][1] +  Students[std_Id][2];
                        System.out.println("Total marks for student: " + tot);
                    }
                    else{
                        System.out.println("Invalid Student ID.");
                    }
                    break;

                case 6:
                    running = false;
                    break;
                case 7:
                    System.out.println("\nSummary of Grades.");
                    System.out.println("StdId\t\tMath\t\tChem\t\tPhysics");

                    for (int i = 1; i <= n; i++){
                        System.out.println(i + "\t" +
                                Students[i][0] + " " + grading(Students[i][0]) + "\t\t" +
                                Students[i][1] + " " + grading(Students[i][1]) + "\t\t" +
                                Students[i][2] + " " + grading(Students[i][2]) + "\t");
                    }
                    break;
            }
        }
    }
    static String grading(int marks){
        if (marks >= 90){
            return "Grade A";
        }
        else if (marks >= 80){
            return "Grade B";
        }
        else if (marks >= 70){
            return "Grade C";
        }
        else if (marks >= 60){
            return "Grade D";
        }
        else{
            return "Fail";
        }
    }
}