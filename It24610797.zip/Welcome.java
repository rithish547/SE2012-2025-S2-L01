import java.util.Scanner; 

public class Welcome{ 
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in); 
		String firstName; 
		String lastName; 

		System.out.print("Enter your First name: "); 
		firstName = scan.nextLine(); 
		System.out.print("Enter your Last name: "); 
		lastName = scan.nextLine(); 
		
		System.out.println("Welcome to the Second Year " + firstName + " " + lastName);
		scan.close();
	}
}